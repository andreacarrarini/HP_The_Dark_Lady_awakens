Buongiorno prof,

ci scusiamo per l'inconveniente, ma abbiamo letto i limiti di parole in ritardo e ormai la storia era già stata scritta, speriamo almeno sia avvincente.

BBBB