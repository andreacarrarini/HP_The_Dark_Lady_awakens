It is highly advisable to click on the team name and listen until the end.
Enjoy ;)